const firebaseConfig = {
    apiKey: "AIzaSyCjHM6va1LRIwwRVYhcQonV_DnDvZX4k30",
    authDomain: "grocer-valley.firebaseapp.com",
    projectId: "grocer-valley",
    storageBucket: "grocer-valley.appspot.com",
    messagingSenderId: "487182679120",
    appId: "1:487182679120:web:51d03e045a35be5cb26555"
  }; 

export default firebaseConfig;